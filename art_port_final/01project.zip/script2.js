
let fileinput = document.getElementById('finput');
let theh2 = document.getElementById('theh2');
let theh4 = document.getElementById('theh4');
let theimg = document.getElementById('theimg');

fileinput.onchange = function() {

    let inp1Value = document.getElementById('inp1').value;
    let inp2Value = document.getElementById('inp2').value;
    
    theh2.textContent = inp1Value;
    theh4.textContent = inp2Value;

    theimg.src = URL.createObjectURL(fileinput.files[0]);
};